package parser

//go:generate ./generate.sh
